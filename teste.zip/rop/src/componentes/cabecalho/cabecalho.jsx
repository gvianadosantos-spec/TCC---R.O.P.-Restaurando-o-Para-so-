import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { HashLink } from "react-router-hash-link";

import "./cabecalho.scss";

function Cabecalho() {
  const [rolou, setRolou] = useState(false);

  useEffect(() => {
    function aoRolar() {
      setRolou(window.scrollY > 10);
    }

    aoRolar();

    window.addEventListener("scroll", aoRolar, {
      passive: true,
    });

    return () => {
      window.removeEventListener("scroll", aoRolar);
    };
  }, []);

  return (
    <>
      <header
        className={`comp-cabecalho ${rolou ? "rolou" : ""}`}
      >
        <div className="comp-corpo">
          <Link
            to="/inicio"
            className="comp-logo"
            aria-label="R.O.P. — Ir para o início"
          >
            <img
              src="/assets/img/componentes/cabecalho/logo.png"
              alt="R.O.P. — Restaurando o Paraíso"
            />
          </Link>

          <nav
            className="comp-botoes"
            aria-label="Navegação principal"
          >
            <Link to="/inicio" className="comp-link">
              Início
            </Link>

            <Link to="/especies" className="comp-link">
              Espécies
            </Link>

            <Link to="/noticias" className="comp-link">
              Notícias
            </Link>

            <HashLink
              smooth
              to="/inicio#impactos"
              className="comp-link"
            >
              Impactos
            </HashLink>

            <HashLink
              smooth
              to="/inicio#projetos"
              className="comp-link"
            >
              Projetos
            </HashLink>

            <HashLink
              smooth
              to="/inicio#apadrinhe"
              className="comp-link"
            >
              Apadrinhe
            </HashLink>

            <Link to="/loja" className="comp-link">
              Loja
            </Link>
          </nav>

          <div className="comp-acoes">
            <Link to="/" className="comp-login">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <circle cx="12" cy="8" r="4" />
                <path d="M5 21v-2a7 7 0 0 1 14 0v2" />
              </svg>

              <span>Login</span>
            </Link>

            <div className="comp-doe-div">
              <Link to="/doe" className="comp-doe">
                <img
                  src="/assets/img/componentes/cabecalho/coracao.png"
                  alt=""
                  className="icone-coracao"
                />

                <span>Doe agora</span>
              </Link>
            </div>
          </div>
        </div>

        <div
          className="comp-aviso"
          role="note"
          aria-hidden={rolou}
        >
          <b>Projeto fictício.</b>

          <span className="comp-aviso-longo">
            A R.O.P. não existe de verdade.
            Este site foi criado para um TCC.
          </span>

          <span className="comp-aviso-curto">
            Site criado para um TCC.
          </span>
        </div>
      </header>

      <div className="comp-espaco" aria-hidden="true" />
    </>
  );
}

export default Cabecalho;